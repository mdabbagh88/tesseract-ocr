var NAVTREE =
[
  [ "Tesseract", "index.html", [
    [ "Related Pages", "pages.html", [
      [ "Deprecated List", "deprecated.html", null ]
    ] ],
    [ "Modules", "modules.html", [
      [ "Advanced API", "group___advanced_a_p_i.html", null ],
      [ "ocropus add-ons", "group__ocropus_add_ons.html", [
        [ "ThresholderParams", "group___thresholder_params.html", null ]
      ] ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "_ConstTessMemberResultCallback_0_0< del, R, T >", "class___const_tess_member_result_callback__0__0.html", null ],
      [ "_ConstTessMemberResultCallback_0_0< del, void, T >", "class___const_tess_member_result_callback__0__0_3_01del_00_01void_00_01_t_01_4.html", null ],
      [ "_ConstTessMemberResultCallback_0_1< del, R, T, A1 >", "class___const_tess_member_result_callback__0__1.html", null ],
      [ "_ConstTessMemberResultCallback_0_1< del, void, T, A1 >", "class___const_tess_member_result_callback__0__1_3_01del_00_01void_00_01_t_00_01_a1_01_4.html", null ],
      [ "_ConstTessMemberResultCallback_0_2< del, R, T, A1, A2 >", "class___const_tess_member_result_callback__0__2.html", null ],
      [ "_ConstTessMemberResultCallback_0_2< del, void, T, A1, A2 >", "class___const_tess_member_result_callback__0__2_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_01_4.html", null ],
      [ "_ConstTessMemberResultCallback_0_3< del, R, T, A1, A2, A3 >", "class___const_tess_member_result_callback__0__3.html", null ],
      [ "_ConstTessMemberResultCallback_0_3< del, void, T, A1, A2, A3 >", "class___const_tess_member_result_callback__0__3_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ],
      [ "_ConstTessMemberResultCallback_1_2< del, R, T, P1, A1, A2 >", "class___const_tess_member_result_callback__1__2.html", null ],
      [ "_ConstTessMemberResultCallback_1_2< del, void, T, P1, A1, A2 >", "class___const_tess_member_result_callback__1__2_3_01del_00_01void_00_01_t_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ],
      [ "tesseract::_MATCH_", "structtesseract_1_1___m_a_t_c_h__.html", null ],
      [ "_TALLY_", "struct___t_a_l_l_y__.html", null ],
      [ "_TessFunctionResultCallback_0_0< del, R >", "class___tess_function_result_callback__0__0.html", null ],
      [ "_TessFunctionResultCallback_0_0< del, void >", "class___tess_function_result_callback__0__0_3_01del_00_01void_01_4.html", null ],
      [ "_TessFunctionResultCallback_0_1< del, R, A1 >", "class___tess_function_result_callback__0__1.html", null ],
      [ "_TessFunctionResultCallback_0_1< del, void, A1 >", "class___tess_function_result_callback__0__1_3_01del_00_01void_00_01_a1_01_4.html", null ],
      [ "_TessFunctionResultCallback_0_2< del, R, A1, A2 >", "class___tess_function_result_callback__0__2.html", null ],
      [ "_TessFunctionResultCallback_0_2< del, void, A1, A2 >", "class___tess_function_result_callback__0__2_3_01del_00_01void_00_01_a1_00_01_a2_01_4.html", null ],
      [ "_TessFunctionResultCallback_0_3< del, R, A1, A2, A3 >", "class___tess_function_result_callback__0__3.html", null ],
      [ "_TessFunctionResultCallback_0_3< del, void, A1, A2, A3 >", "class___tess_function_result_callback__0__3_3_01del_00_01void_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ],
      [ "_TessFunctionResultCallback_1_2< del, R, P1, A1, A2 >", "class___tess_function_result_callback__1__2.html", null ],
      [ "_TessFunctionResultCallback_1_2< del, void, P1, A1, A2 >", "class___tess_function_result_callback__1__2_3_01del_00_01void_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ],
      [ "_TessMemberResultCallback_0_0< del, R, T >", "class___tess_member_result_callback__0__0.html", null ],
      [ "_TessMemberResultCallback_0_0< del, void, T >", "class___tess_member_result_callback__0__0_3_01del_00_01void_00_01_t_01_4.html", null ],
      [ "_TessMemberResultCallback_0_1< del, R, T, A1 >", "class___tess_member_result_callback__0__1.html", null ],
      [ "_TessMemberResultCallback_0_1< del, void, T, A1 >", "class___tess_member_result_callback__0__1_3_01del_00_01void_00_01_t_00_01_a1_01_4.html", null ],
      [ "_TessMemberResultCallback_0_2< del, R, T, A1, A2 >", "class___tess_member_result_callback__0__2.html", null ],
      [ "_TessMemberResultCallback_0_2< del, void, T, A1, A2 >", "class___tess_member_result_callback__0__2_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_01_4.html", null ],
      [ "_TessMemberResultCallback_0_3< del, R, T, A1, A2, A3 >", "class___tess_member_result_callback__0__3.html", null ],
      [ "_TessMemberResultCallback_0_3< del, void, T, A1, A2, A3 >", "class___tess_member_result_callback__0__3_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ],
      [ "_TessMemberResultCallback_1_2< del, R, T, P1, A1, A2 >", "class___tess_member_result_callback__1__2.html", null ],
      [ "_TessMemberResultCallback_1_2< del, void, T, P1, A1, A2 >", "class___tess_member_result_callback__1__2_3_01del_00_01void_00_01_t_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ],
      [ "ADAPT_CLASS_STRUCT", "struct_a_d_a_p_t___c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "ADAPT_RESULTS", "struct_a_d_a_p_t___r_e_s_u_l_t_s.html", null ],
      [ "ADAPT_TEMPLATES_STRUCT", "struct_a_d_a_p_t___t_e_m_p_l_a_t_e_s___s_t_r_u_c_t.html", null ],
      [ "ADAPTED_CONFIG", "union_a_d_a_p_t_e_d___c_o_n_f_i_g.html", null ],
      [ "tesseract::AlignedBlob", "classtesseract_1_1_aligned_blob.html", null ],
      [ "tesseract::AlignedBlobParams", "structtesseract_1_1_aligned_blob_params.html", null ],
      [ "tesseract::AltList", "classtesseract_1_1_alt_list.html", null ],
      [ "tesseract::AmbigSpec", "classtesseract_1_1_ambig_spec.html", null ],
      [ "array_record", "structarray__record.html", null ],
      [ "tesseract::AssociateStats", "structtesseract_1_1_associate_stats.html", null ],
      [ "tesseract::AssociateUtils", "classtesseract_1_1_associate_utils.html", null ],
      [ "BAND", "class_b_a_n_d.html", null ],
      [ "tesseract::BBGrid< BBC, BBC_CLIST, BBC_C_IT >", "classtesseract_1_1_b_b_grid.html", null ],
      [ "tesseract::BeamSearch", "classtesseract_1_1_beam_search.html", null ],
      [ "tesseract::BestChoiceBundle", "structtesseract_1_1_best_choice_bundle.html", null ],
      [ "tesseract::BestPathByColumn", "structtesseract_1_1_best_path_by_column.html", null ],
      [ "tesseract::Bigram", "structtesseract_1_1_bigram.html", null ],
      [ "BITS16", "class_b_i_t_s16.html", null ],
      [ "BlnEventHandler", "class_bln_event_handler.html", null ],
      [ "BLOB_CHOICE", "class_b_l_o_b___c_h_o_i_c_e.html", null ],
      [ "tesseract::BlobMatchTable", "classtesseract_1_1_blob_match_table.html", null ],
      [ "BLOBNBOX", "class_b_l_o_b_n_b_o_x.html", null ],
      [ "BLOCK", "class_b_l_o_c_k.html", null ],
      [ "BLOCK_LINE_IT", "class_b_l_o_c_k___l_i_n_e___i_t.html", null ],
      [ "BLOCK_RECT_IT", "class_b_l_o_c_k___r_e_c_t___i_t.html", null ],
      [ "BLOCK_RES", "class_b_l_o_c_k___r_e_s.html", null ],
      [ "tesseract::Bmp8", "classtesseract_1_1_bmp8.html", null ],
      [ "tesseract::BoolParam", "classtesseract_1_1_bool_param.html", null ],
      [ "BOUNDS", "struct_b_o_u_n_d_s.html", null ],
      [ "tesseract::BoxWord", "classtesseract_1_1_box_word.html", null ],
      [ "BUCKETS", "struct_b_u_c_k_e_t_s.html", null ],
      [ "C_BLOB", "class_c___b_l_o_b.html", null ],
      [ "C_OUTLINE", "class_c___o_u_t_l_i_n_e.html", null ],
      [ "C_OUTLINE_FRAG", "class_c___o_u_t_l_i_n_e___f_r_a_g.html", null ],
      [ "tesseract::CachedFile", "classtesseract_1_1_cached_file.html", null ],
      [ "tesseract::CCStruct", "classtesseract_1_1_c_c_struct.html", null ],
      [ "tesseract::CCUtil", "classtesseract_1_1_c_c_util.html", null ],
      [ "tesseract::CCUtilMutex", "classtesseract_1_1_c_c_util_mutex.html", null ],
      [ "CHAR_CHOICE", "struct_c_h_a_r___c_h_o_i_c_e.html", null ],
      [ "CHAR_DESC_STRUCT", "struct_c_h_a_r___d_e_s_c___s_t_r_u_c_t.html", null ],
      [ "CHAR_FRAGMENT", "class_c_h_a_r___f_r_a_g_m_e_n_t.html", null ],
      [ "CHAR_FRAGMENT_INFO", "struct_c_h_a_r___f_r_a_g_m_e_n_t___i_n_f_o.html", null ],
      [ "tesseract::CharAltList", "classtesseract_1_1_char_alt_list.html", null ],
      [ "tesseract::CharBigram", "structtesseract_1_1_char_bigram.html", null ],
      [ "tesseract::CharBigrams", "classtesseract_1_1_char_bigrams.html", null ],
      [ "tesseract::CharBigramTable", "structtesseract_1_1_char_bigram_table.html", null ],
      [ "tesseract::CharClassifier", "classtesseract_1_1_char_classifier.html", null ],
      [ "tesseract::CharClassifierFactory", "classtesseract_1_1_char_classifier_factory.html", null ],
      [ "tesseract::CharSamp", "classtesseract_1_1_char_samp.html", null ],
      [ "tesseract::CharSampEnum", "classtesseract_1_1_char_samp_enum.html", null ],
      [ "tesseract::CharSampSet", "classtesseract_1_1_char_samp_set.html", null ],
      [ "tesseract::CharSet", "classtesseract_1_1_char_set.html", null ],
      [ "CHISTRUCT", "struct_c_h_i_s_t_r_u_c_t.html", null ],
      [ "tesseract::ChoiceIterator", "classtesseract_1_1_choice_iterator.html", null ],
      [ "CHUNKS_RECORD", "struct_c_h_u_n_k_s___r_e_c_o_r_d.html", null ],
      [ "CLASS_STRUCT", "struct_c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "tesseract::Classify", "classtesseract_1_1_classify.html", null ],
      [ "ClassPrunerData", "struct_class_pruner_data.html", null ],
      [ "CLIST", "class_c_l_i_s_t.html", null ],
      [ "CLIST_ITERATOR", "class_c_l_i_s_t___i_t_e_r_a_t_o_r.html", null ],
      [ "CLIST_LINK", "class_c_l_i_s_t___l_i_n_k.html", null ],
      [ "CLUSTERCONFIG", "struct_c_l_u_s_t_e_r_c_o_n_f_i_g.html", null ],
      [ "CLUSTERER", "struct_c_l_u_s_t_e_r_e_r.html", null ],
      [ "ClusteringContext", "struct_clustering_context.html", null ],
      [ "tesseract::ColPartition", "classtesseract_1_1_col_partition.html", null ],
      [ "tesseract::ColPartitionGrid", "classtesseract_1_1_col_partition_grid.html", null ],
      [ "tesseract::ColPartitionSet", "classtesseract_1_1_col_partition_set.html", null ],
      [ "tesseract::ColSegment", "classtesseract_1_1_col_segment.html", null ],
      [ "tesseract::ColumnFinder", "classtesseract_1_1_column_finder.html", null ],
      [ "tesseract::ConComp", "classtesseract_1_1_con_comp.html", null ],
      [ "tesseract::ConCompPt", "classtesseract_1_1_con_comp_pt.html", null ],
      [ "tesseract::ConvNetCharClassifier", "classtesseract_1_1_conv_net_char_classifier.html", null ],
      [ "CP_RESULT_STRUCT", "struct_c_p___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "CRACKEDGE", "class_c_r_a_c_k_e_d_g_e.html", null ],
      [ "CrackPos", "struct_crack_pos.html", null ],
      [ "tesseract::CubeLineObject", "classtesseract_1_1_cube_line_object.html", null ],
      [ "tesseract::CubeLineSegmenter", "classtesseract_1_1_cube_line_segmenter.html", null ],
      [ "tesseract::CubeObject", "classtesseract_1_1_cube_object.html", null ],
      [ "tesseract::CubeRecoContext", "classtesseract_1_1_cube_reco_context.html", null ],
      [ "tesseract::CubeSearchObject", "classtesseract_1_1_cube_search_object.html", null ],
      [ "tesseract::CubeTuningParams", "classtesseract_1_1_cube_tuning_params.html", null ],
      [ "tesseract::CubeUtils", "classtesseract_1_1_cube_utils.html", null ],
      [ "tesseract::CUtil", "classtesseract_1_1_c_util.html", null ],
      [ "DANGERR_INFO", "struct_d_a_n_g_e_r_r___i_n_f_o.html", null ],
      [ "tesseract::Dawg", "classtesseract_1_1_dawg.html", null ],
      [ "tesseract::DawgArgs", "structtesseract_1_1_dawg_args.html", null ],
      [ "tesseract::DawgInfo", "structtesseract_1_1_dawg_info.html", null ],
      [ "tesseract::DawgInfoVector", "classtesseract_1_1_dawg_info_vector.html", null ],
      [ "DENORM", "class_d_e_n_o_r_m.html", null ],
      [ "DENORM_SEG", "class_d_e_n_o_r_m___s_e_g.html", null ],
      [ "tesseract::DetLineFit", "classtesseract_1_1_det_line_fit.html", null ],
      [ "tesseract::Dict", "classtesseract_1_1_dict.html", null ],
      [ "DIR128", "class_d_i_r128.html", null ],
      [ "tesseract::DocQualCallbacks", "structtesseract_1_1_doc_qual_callbacks.html", null ],
      [ "tesseract::DoubleParam", "classtesseract_1_1_double_param.html", null ],
      [ "tesseract::DPPoint", "classtesseract_1_1_d_p_point.html", null ],
      [ "EANYCODE_CHAR", "struct_e_a_n_y_c_o_d_e___c_h_a_r.html", null ],
      [ "EDGEPT", "struct_e_d_g_e_p_t.html", null ],
      [ "EFONT_DESC", "struct_e_f_o_n_t___d_e_s_c.html", null ],
      [ "MinK< Key, Value >::Element", "struct_min_k_1_1_element.html", null ],
      [ "ELIST", "class_e_l_i_s_t.html", null ],
      [ "ELIST2", "class_e_l_i_s_t2.html", null ],
      [ "ELIST2_ITERATOR", "class_e_l_i_s_t2___i_t_e_r_a_t_o_r.html", null ],
      [ "ELIST2_LINK", "class_e_l_i_s_t2___l_i_n_k.html", null ],
      [ "ELIST_ITERATOR", "class_e_l_i_s_t___i_t_e_r_a_t_o_r.html", null ],
      [ "ELIST_LINK", "class_e_l_i_s_t___l_i_n_k.html", null ],
      [ "EOCR_DESC", "struct_e_o_c_r___d_e_s_c.html", null ],
      [ "ERRCODE", "class_e_r_r_c_o_d_e.html", null ],
      [ "ESTRIP_DESC", "struct_e_s_t_r_i_p___d_e_s_c.html", null ],
      [ "ETEXT_DESC", "class_e_t_e_x_t___d_e_s_c.html", null ],
      [ "EVALUATION_RECORD", "struct_e_v_a_l_u_a_t_i_o_n___r_e_c_o_r_d.html", null ],
      [ "EXPANDED_CHOICE", "struct_e_x_p_a_n_d_e_d___c_h_o_i_c_e.html", null ],
      [ "FCOORD", "class_f_c_o_o_r_d.html", null ],
      [ "FEATURE_DEFS_STRUCT", "struct_f_e_a_t_u_r_e___d_e_f_s___s_t_r_u_c_t.html", null ],
      [ "FEATURE_DESC_STRUCT", "struct_f_e_a_t_u_r_e___d_e_s_c___s_t_r_u_c_t.html", null ],
      [ "FEATURE_EXT_STRUCT", "struct_f_e_a_t_u_r_e___e_x_t___s_t_r_u_c_t.html", null ],
      [ "FEATURE_SET_STRUCT", "struct_f_e_a_t_u_r_e___s_e_t___s_t_r_u_c_t.html", null ],
      [ "FEATURE_STRUCT", "struct_f_e_a_t_u_r_e___s_t_r_u_c_t.html", null ],
      [ "tesseract::FeatureBase", "classtesseract_1_1_feature_base.html", null ],
      [ "tesseract::FeatureBmp", "classtesseract_1_1_feature_bmp.html", null ],
      [ "tesseract::FeatureChebyshev", "classtesseract_1_1_feature_chebyshev.html", null ],
      [ "tesseract::FeatureHybrid", "classtesseract_1_1_feature_hybrid.html", null ],
      [ "FILL_SPEC", "struct_f_i_l_l___s_p_e_c.html", null ],
      [ "FILL_SWITCH", "struct_f_i_l_l___s_w_i_t_c_h.html", null ],
      [ "FLOATUNION", "union_f_l_o_a_t_u_n_i_o_n.html", null ],
      [ "FontInfo", "struct_font_info.html", null ],
      [ "tesseract::FontPairSizeInfo", "structtesseract_1_1_font_pair_size_info.html", null ],
      [ "FontSet", "struct_font_set.html", null ],
      [ "FontSpacingInfo", "struct_font_spacing_info.html", null ],
      [ "FPCUTPT", "class_f_p_c_u_t_p_t.html", null ],
      [ "FPOINT", "struct_f_p_o_i_n_t.html", null ],
      [ "FPSEGPT", "class_f_p_s_e_g_p_t.html", null ],
      [ "tesseract::FRAGMENT", "classtesseract_1_1_f_r_a_g_m_e_n_t.html", null ],
      [ "FRECT", "struct_f_r_e_c_t.html", null ],
      [ "FREE_CALL", "class_f_r_e_e___c_a_l_l.html", null ],
      [ "GAPMAP", "class_g_a_p_m_a_p.html", null ],
      [ "GENERIC_2D_ARRAY< T >", "class_g_e_n_e_r_i_c__2_d___a_r_r_a_y.html", null ],
      [ "GENERIC_MATRIX< T >", "class_g_e_n_e_r_i_c___m_a_t_r_i_x.html", null ],
      [ "GenericVector< T >", "class_generic_vector.html", null ],
      [ "GenericVectorEqEq< T >", "class_generic_vector_eq_eq.html", null ],
      [ "tesseract::GridBase", "classtesseract_1_1_grid_base.html", null ],
      [ "tesseract::GridSearch< BBC, BBC_CLIST, BBC_C_IT >", "classtesseract_1_1_grid_search.html", null ],
      [ "HEAP", "struct_h_e_a_p.html", null ],
      [ "HEAPENTRY", "struct_h_e_a_p_e_n_t_r_y.html", null ],
      [ "tesseract::HybridNeuralNetCharClassifier", "classtesseract_1_1_hybrid_neural_net_char_classifier.html", null ],
      [ "ICOORD", "class_i_c_o_o_r_d.html", null ],
      [ "ICOORDELT", "class_i_c_o_o_r_d_e_l_t.html", null ],
      [ "Identity< T >", "struct_identity.html", null ],
      [ "tesseract::Image", "classtesseract_1_1_image.html", null ],
      [ "IMAGE", "class_i_m_a_g_e.html", null ],
      [ "tesseract::ImageFinder", "classtesseract_1_1_image_finder.html", null ],
      [ "IMAGELINE", "class_i_m_a_g_e_l_i_n_e.html", null ],
      [ "tesseract::ImageThresholder", "classtesseract_1_1_image_thresholder.html", null ],
      [ "tesseract::InputFileBuffer", "classtesseract_1_1_input_file_buffer.html", null ],
      [ "INT_CLASS_STRUCT", "struct_i_n_t___c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "INT_FEATURE_STRUCT", "struct_i_n_t___f_e_a_t_u_r_e___s_t_r_u_c_t.html", null ],
      [ "INT_FX_RESULT_STRUCT", "struct_i_n_t___f_x___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "INT_PROTO_STRUCT", "struct_i_n_t___p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "INT_RESULT_STRUCT", "struct_i_n_t___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "INT_TEMPLATES_STRUCT", "struct_i_n_t___t_e_m_p_l_a_t_e_s___s_t_r_u_c_t.html", null ],
      [ "IntegerMatcher", "class_integer_matcher.html", null ],
      [ "tesseract::IntGrid", "classtesseract_1_1_int_grid.html", null ],
      [ "tesseract::IntParam", "classtesseract_1_1_int_param.html", null ],
      [ "KDNODE", "struct_k_d_n_o_d_e.html", null ],
      [ "KDTREE", "struct_k_d_t_r_e_e.html", null ],
      [ "KDTreeSearch", "class_k_d_tree_search.html", null ],
      [ "LABELEDLISTNODE", "struct_l_a_b_e_l_e_d_l_i_s_t_n_o_d_e.html", null ],
      [ "tesseract::LangModEdge", "classtesseract_1_1_lang_mod_edge.html", null ],
      [ "tesseract::LangModel", "classtesseract_1_1_lang_model.html", null ],
      [ "tesseract::LanguageModel", "classtesseract_1_1_language_model.html", null ],
      [ "tesseract::LanguageModelConsistencyInfo", "structtesseract_1_1_language_model_consistency_info.html", null ],
      [ "tesseract::LanguageModelDawgInfo", "structtesseract_1_1_language_model_dawg_info.html", null ],
      [ "tesseract::LanguageModelNgramInfo", "structtesseract_1_1_language_model_ngram_info.html", null ],
      [ "tesseract::LanguageModelState", "structtesseract_1_1_language_model_state.html", null ],
      [ "tesseract::LineFinder", "classtesseract_1_1_line_finder.html", null ],
      [ "list_rec", "structlist__rec.html", null ],
      [ "LLSQ", "class_l_l_s_q.html", null ],
      [ "MALLOC_CALL", "class_m_a_l_l_o_c___c_a_l_l.html", null ],
      [ "MATCH_RESULT", "struct_m_a_t_c_h___r_e_s_u_l_t.html", null ],
      [ "MATRIX", "class_m_a_t_r_i_x.html", null ],
      [ "MATRIX_2D", "struct_m_a_t_r_i_x__2_d.html", null ],
      [ "MATRIX_COORD", "struct_m_a_t_r_i_x___c_o_o_r_d.html", null ],
      [ "MEASUREMENT", "struct_m_e_a_s_u_r_e_m_e_n_t.html", null ],
      [ "MEM_ALLOCATOR", "class_m_e_m___a_l_l_o_c_a_t_o_r.html", null ],
      [ "MEMBLOCK", "class_m_e_m_b_l_o_c_k.html", null ],
      [ "MEMUNION", "class_m_e_m_u_n_i_o_n.html", null ],
      [ "MERGE_CLASS_NODE", "struct_m_e_r_g_e___c_l_a_s_s___n_o_d_e.html", null ],
      [ "MFEDGEPT", "struct_m_f_e_d_g_e_p_t.html", null ],
      [ "MinK< Key, Value >", "class_min_k.html", null ],
      [ "tesseract::NeuralNet", "classtesseract_1_1_neural_net.html", null ],
      [ "tesseract::Neuron", "classtesseract_1_1_neuron.html", null ],
      [ "tesseract::NeuralNet::Node", "structtesseract_1_1_neural_net_1_1_node.html", null ],
      [ "tesseract::NodeChild", "structtesseract_1_1_node_child.html", null ],
      [ "NORM_PROTOS", "struct_n_o_r_m___p_r_o_t_o_s.html", null ],
      [ "OL_BUCKETS", "class_o_l___b_u_c_k_e_t_s.html", null ],
      [ "OrientationDetector", "class_orientation_detector.html", null ],
      [ "OSBestResult", "struct_o_s_best_result.html", null ],
      [ "OSResults", "struct_o_s_results.html", null ],
      [ "OUTLINE_STATS", "struct_o_u_t_l_i_n_e___s_t_a_t_s.html", null ],
      [ "PAGE_RES", "class_p_a_g_e___r_e_s.html", null ],
      [ "PAGE_RES_IT", "class_p_a_g_e___r_e_s___i_t.html", null ],
      [ "tesseract::PageIterator", "classtesseract_1_1_page_iterator.html", null ],
      [ "tesseract::PairSizeInfo", "structtesseract_1_1_pair_size_info.html", null ],
      [ "tesseract::Param", "classtesseract_1_1_param.html", null ],
      [ "PARAM_DESC", "struct_p_a_r_a_m___d_e_s_c.html", null ],
      [ "ParamContent", "class_param_content.html", null ],
      [ "ParamsEditor", "class_params_editor.html", null ],
      [ "tesseract::ParamsVectors", "structtesseract_1_1_params_vectors.html", null ],
      [ "tesseract::ParamUtils", "classtesseract_1_1_param_utils.html", null ],
      [ "PB_LINE_IT", "class_p_b___l_i_n_e___i_t.html", null ],
      [ "PDBLK", "class_p_d_b_l_k.html", null ],
      [ "PERM_CONFIG_STRUCT", "struct_p_e_r_m___c_o_n_f_i_g___s_t_r_u_c_t.html", null ],
      [ "tesseract::PermuterState", "classtesseract_1_1_permuter_state.html", null ],
      [ "PGEventHandler", "class_p_g_event_handler.html", null ],
      [ "tesseract::PixelHistogram", "classtesseract_1_1_pixel_histogram.html", null ],
      [ "tesseract::PointerVector< T >", "classtesseract_1_1_pointer_vector.html", null ],
      [ "POLY_BLOCK", "class_p_o_l_y___b_l_o_c_k.html", null ],
      [ "PROTO_KEY", "struct_p_r_o_t_o___k_e_y.html", null ],
      [ "PROTO_SET_STRUCT", "struct_p_r_o_t_o___s_e_t___s_t_r_u_c_t.html", null ],
      [ "PROTO_STRUCT", "struct_p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "PROTOTYPE", "struct_p_r_o_t_o_t_y_p_e.html", null ],
      [ "QLSQ", "class_q_l_s_q.html", null ],
      [ "QRSequenceGenerator", "class_q_r_sequence_generator.html", null ],
      [ "QSPLINE", "class_q_s_p_l_i_n_e.html", null ],
      [ "QUAD_COEFFS", "class_q_u_a_d___c_o_e_f_f_s.html", null ],
      [ "REGION_OCC", "class_r_e_g_i_o_n___o_c_c.html", null ],
      [ "REJ", "class_r_e_j.html", null ],
      [ "REJMAP", "class_r_e_j_m_a_p.html", null ],
      [ "remove_reference< T >", "structremove__reference.html", null ],
      [ "remove_reference< T & >", "structremove__reference_3_01_t_01_6_01_4.html", null ],
      [ "tesseract::ResultIterator", "classtesseract_1_1_result_iterator.html", null ],
      [ "ROW", "class_r_o_w.html", null ],
      [ "ROW_RES", "class_r_o_w___r_e_s.html", null ],
      [ "sample", "structsample.html", null ],
      [ "SAMPLELIST", "struct_s_a_m_p_l_e_l_i_s_t.html", null ],
      [ "ScoredClass", "struct_scored_class.html", null ],
      [ "ScratchEvidence", "struct_scratch_evidence.html", null ],
      [ "ScriptDetector", "class_script_detector.html", null ],
      [ "com::google::scrollview::ScrollView", "classcom_1_1google_1_1scrollview_1_1_scroll_view.html", null ],
      [ "ScrollView", "class_scroll_view.html", null ],
      [ "seam_record", "structseam__record.html", null ],
      [ "SEARCH_RECORD", "struct_s_e_a_r_c_h___r_e_c_o_r_d.html", null ],
      [ "tesseract::SearchColumn", "classtesseract_1_1_search_column.html", null ],
      [ "tesseract::SearchNode", "classtesseract_1_1_search_node.html", null ],
      [ "tesseract::SearchNodeHashTable", "classtesseract_1_1_search_node_hash_table.html", null ],
      [ "tesseract::SearchObject", "classtesseract_1_1_search_object.html", null ],
      [ "SEG_SEARCH_PENDING", "struct_s_e_g___s_e_a_r_c_h___p_e_n_d_i_n_g.html", null ],
      [ "tesseract::ShiroRekhaSplitter", "classtesseract_1_1_shiro_rekha_splitter.html", null ],
      [ "SORTED_FLOAT", "class_s_o_r_t_e_d___f_l_o_a_t.html", null ],
      [ "SORTED_FLOATS", "class_s_o_r_t_e_d___f_l_o_a_t_s.html", null ],
      [ "SortHelper< T >", "class_sort_helper.html", null ],
      [ "SortHelper< T >::SortPair< PairT >", "struct_sort_helper_1_1_sort_pair.html", null ],
      [ "split_record", "structsplit__record.html", null ],
      [ "tesseract::SquishedDawg", "classtesseract_1_1_squished_dawg.html", null ],
      [ "STATE", "struct_s_t_a_t_e.html", null ],
      [ "STATISTICS", "struct_s_t_a_t_i_s_t_i_c_s.html", null ],
      [ "STATS", "class_s_t_a_t_s.html", null ],
      [ "STRING", "class_s_t_r_i_n_g.html", null ],
      [ "tesseract::StringParam", "classtesseract_1_1_string_param.html", null ],
      [ "tesseract::StrokeWidth", "classtesseract_1_1_stroke_width.html", null ],
      [ "tesseract::StructuredTable", "classtesseract_1_1_structured_table.html", null ],
      [ "com::google::scrollview::ui::SVAbstractMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_abstract_menu_item.html", null ],
      [ "com::google::scrollview::ui::SVCheckboxMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_checkbox_menu_item.html", null ],
      [ "com::google::scrollview::ui::SVEmptyMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_empty_menu_item.html", null ],
      [ "com::google::scrollview::events::SVEvent", "classcom_1_1google_1_1scrollview_1_1events_1_1_s_v_event.html", null ],
      [ "SVEvent", "struct_s_v_event.html", null ],
      [ "com::google::scrollview::events::SVEventHandler", "classcom_1_1google_1_1scrollview_1_1events_1_1_s_v_event_handler.html", null ],
      [ "SVEventHandler", "class_s_v_event_handler.html", null ],
      [ "com::google::scrollview::ui::SVImageHandler", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_image_handler.html", null ],
      [ "com::google::scrollview::ui::SVMenuBar", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_menu_bar.html", null ],
      [ "com::google::scrollview::ui::SVMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_menu_item.html", null ],
      [ "SVMenuNode", "class_s_v_menu_node.html", null ],
      [ "SVMutex", "class_s_v_mutex.html", null ],
      [ "SVNetwork", "class_s_v_network.html", null ],
      [ "SVPaint", "class_s_v_paint.html", null ],
      [ "SVPolyLineBuffer", "struct_s_v_poly_line_buffer.html", null ],
      [ "com::google::scrollview::ui::SVPopupMenu", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_popup_menu.html", null ],
      [ "SVSemaphore", "class_s_v_semaphore.html", null ],
      [ "com::google::scrollview::ui::SVSubMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_sub_menu_item.html", null ],
      [ "SVSync", "class_s_v_sync.html", null ],
      [ "com::google::scrollview::ui::SVWindow", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_window.html", null ],
      [ "tesseract::TabConstraint", "classtesseract_1_1_tab_constraint.html", null ],
      [ "tesseract::TabEventHandler< G >", "classtesseract_1_1_tab_event_handler.html", null ],
      [ "tesseract::TabFind", "classtesseract_1_1_tab_find.html", null ],
      [ "TABLE_FILLER", "struct_t_a_b_l_e___f_i_l_l_e_r.html", null ],
      [ "tesseract::TableFinder", "classtesseract_1_1_table_finder.html", null ],
      [ "tesseract::TableRecognizer", "classtesseract_1_1_table_recognizer.html", null ],
      [ "tesseract::TabVector", "classtesseract_1_1_tab_vector.html", null ],
      [ "TBLOB", "struct_t_b_l_o_b.html", null ],
      [ "TBOX", "class_t_b_o_x.html", null ],
      [ "TEMP_CONFIG_STRUCT", "struct_t_e_m_p___c_o_n_f_i_g___s_t_r_u_c_t.html", null ],
      [ "TEMP_PROTO_STRUCT", "struct_t_e_m_p___p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "TEMPCLUSTER", "struct_t_e_m_p_c_l_u_s_t_e_r.html", null ],
      [ "tesseract::TESS_CHAR", "structtesseract_1_1_t_e_s_s___c_h_a_r.html", null ],
      [ "tesseract::TessBaseAPI", "classtesseract_1_1_tess_base_a_p_i.html", null ],
      [ "TessCallback1< A1 >", "class_tess_callback1.html", null ],
      [ "TessCallback2< A1, A2 >", "class_tess_callback2.html", null ],
      [ "TessCallback3< A1, A2, A3 >", "class_tess_callback3.html", null ],
      [ "TessCallbackUtils_", "struct_tess_callback_utils__.html", null ],
      [ "TessClosure", "class_tess_closure.html", null ],
      [ "tesseract::TessdataManager", "classtesseract_1_1_tessdata_manager.html", null ],
      [ "tesseract::Tesseract", "classtesseract_1_1_tesseract.html", null ],
      [ "tesseract::TesseractCubeCombiner", "classtesseract_1_1_tesseract_cube_combiner.html", null ],
      [ "tesseract::TesseractStats", "structtesseract_1_1_tesseract_stats.html", null ],
      [ "tesseract::TessLangModEdge", "classtesseract_1_1_tess_lang_mod_edge.html", null ],
      [ "tesseract::TessLangModel", "classtesseract_1_1_tess_lang_model.html", null ],
      [ "TESSLINE", "struct_t_e_s_s_l_i_n_e.html", null ],
      [ "TessResultCallback< R >", "class_tess_result_callback.html", null ],
      [ "TessResultCallback1< R, A1 >", "class_tess_result_callback1.html", null ],
      [ "TessResultCallback2< R, A1, A2 >", "class_tess_result_callback2.html", null ],
      [ "TessResultCallback3< R, A1, A2, A3 >", "class_tess_result_callback3.html", null ],
      [ "tesseract::Textord", "classtesseract_1_1_textord.html", null ],
      [ "TIFFENTRY", "struct_t_i_f_f_e_n_t_r_y.html", null ],
      [ "TO_BLOCK", "class_t_o___b_l_o_c_k.html", null ],
      [ "TO_ROW", "class_t_o___r_o_w.html", null ],
      [ "TPOINT", "struct_t_p_o_i_n_t.html", null ],
      [ "tesseract::Trie", "classtesseract_1_1_trie.html", null ],
      [ "TRIE_NODE_RECORD", "struct_t_r_i_e___n_o_d_e___r_e_c_o_r_d.html", null ],
      [ "tesseract::TuningParams", "classtesseract_1_1_tuning_params.html", null ],
      [ "TWERD", "struct_t_w_e_r_d.html", null ],
      [ "UNICHAR", "class_u_n_i_c_h_a_r.html", null ],
      [ "tesseract::UnicharAmbigs", "classtesseract_1_1_unichar_ambigs.html", null ],
      [ "tesseract::UnicharIdArrayUtils", "classtesseract_1_1_unichar_id_array_utils.html", null ],
      [ "UNICHARMAP", "class_u_n_i_c_h_a_r_m_a_p.html", null ],
      [ "UNICHARSET", "class_u_n_i_c_h_a_r_s_e_t.html", null ],
      [ "UnicityTable< T >", "class_unicity_table.html", null ],
      [ "UnicityTableEqEq< T >", "class_unicity_table_eq_eq.html", null ],
      [ "UWREC", "class_u_w_r_e_c.html", null ],
      [ "VIABLE_CHOICE_STRUCT", "struct_v_i_a_b_l_e___c_h_o_i_c_e___s_t_r_u_c_t.html", null ],
      [ "tesseract::ViterbiStateEntry", "structtesseract_1_1_viterbi_state_entry.html", null ],
      [ "tesseract::NeuralNet::WeightedNode", "structtesseract_1_1_neural_net_1_1_weighted_node.html", null ],
      [ "WERD", "class_w_e_r_d.html", null ],
      [ "WERD_CHOICE", "class_w_e_r_d___c_h_o_i_c_e.html", null ],
      [ "WERD_RES", "class_w_e_r_d___r_e_s.html", null ],
      [ "WIDTH_RECORD", "struct_w_i_d_t_h___r_e_c_o_r_d.html", null ],
      [ "tesseract::WordAltList", "classtesseract_1_1_word_alt_list.html", null ],
      [ "tesseract::WordListLangModel", "classtesseract_1_1_word_list_lang_model.html", null ],
      [ "tesseract::Wordrec", "classtesseract_1_1_wordrec.html", null ],
      [ "tesseract::WordSizeModel", "classtesseract_1_1_word_size_model.html", null ],
      [ "tesseract::WordUnigrams", "classtesseract_1_1_word_unigrams.html", null ],
      [ "tesseract::WorkingPartSet", "classtesseract_1_1_working_part_set.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "tesseract::_MATCH_", "structtesseract_1_1___m_a_t_c_h__.html", null ],
      [ "_TALLY_", "struct___t_a_l_l_y__.html", null ],
      [ "ADAPT_CLASS_STRUCT", "struct_a_d_a_p_t___c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "ADAPT_RESULTS", "struct_a_d_a_p_t___r_e_s_u_l_t_s.html", null ],
      [ "ADAPT_TEMPLATES_STRUCT", "struct_a_d_a_p_t___t_e_m_p_l_a_t_e_s___s_t_r_u_c_t.html", null ],
      [ "ADAPTED_CONFIG", "union_a_d_a_p_t_e_d___c_o_n_f_i_g.html", null ],
      [ "tesseract::AlignedBlobParams", "structtesseract_1_1_aligned_blob_params.html", null ],
      [ "tesseract::AltList", "classtesseract_1_1_alt_list.html", [
        [ "tesseract::CharAltList", "classtesseract_1_1_char_alt_list.html", null ],
        [ "tesseract::WordAltList", "classtesseract_1_1_word_alt_list.html", null ]
      ] ],
      [ "array_record", "structarray__record.html", null ],
      [ "tesseract::AssociateStats", "structtesseract_1_1_associate_stats.html", null ],
      [ "tesseract::AssociateUtils", "classtesseract_1_1_associate_utils.html", null ],
      [ "BAND", "class_b_a_n_d.html", null ],
      [ "tesseract::BeamSearch", "classtesseract_1_1_beam_search.html", null ],
      [ "tesseract::BestChoiceBundle", "structtesseract_1_1_best_choice_bundle.html", null ],
      [ "tesseract::BestPathByColumn", "structtesseract_1_1_best_path_by_column.html", null ],
      [ "tesseract::Bigram", "structtesseract_1_1_bigram.html", null ],
      [ "BITS16", "class_b_i_t_s16.html", null ],
      [ "tesseract::BlobMatchTable", "classtesseract_1_1_blob_match_table.html", null ],
      [ "BLOCK_LINE_IT", "class_b_l_o_c_k___l_i_n_e___i_t.html", null ],
      [ "BLOCK_RECT_IT", "class_b_l_o_c_k___r_e_c_t___i_t.html", null ],
      [ "tesseract::Bmp8", "classtesseract_1_1_bmp8.html", [
        [ "tesseract::CharSamp", "classtesseract_1_1_char_samp.html", null ]
      ] ],
      [ "BOUNDS", "struct_b_o_u_n_d_s.html", null ],
      [ "tesseract::BoxWord", "classtesseract_1_1_box_word.html", null ],
      [ "BUCKETS", "struct_b_u_c_k_e_t_s.html", null ],
      [ "tesseract::CachedFile", "classtesseract_1_1_cached_file.html", null ],
      [ "tesseract::CCUtil", "classtesseract_1_1_c_c_util.html", [
        [ "tesseract::CUtil", "classtesseract_1_1_c_util.html", [
          [ "tesseract::CCStruct", "classtesseract_1_1_c_c_struct.html", [
            [ "tesseract::Classify", "classtesseract_1_1_classify.html", [
              [ "tesseract::Wordrec", "classtesseract_1_1_wordrec.html", [
                [ "tesseract::Tesseract", "classtesseract_1_1_tesseract.html", null ]
              ] ]
            ] ]
          ] ]
        ] ]
      ] ],
      [ "tesseract::CCUtilMutex", "classtesseract_1_1_c_c_util_mutex.html", null ],
      [ "CHAR_CHOICE", "struct_c_h_a_r___c_h_o_i_c_e.html", null ],
      [ "CHAR_DESC_STRUCT", "struct_c_h_a_r___d_e_s_c___s_t_r_u_c_t.html", null ],
      [ "CHAR_FRAGMENT", "class_c_h_a_r___f_r_a_g_m_e_n_t.html", null ],
      [ "CHAR_FRAGMENT_INFO", "struct_c_h_a_r___f_r_a_g_m_e_n_t___i_n_f_o.html", null ],
      [ "tesseract::CharBigram", "structtesseract_1_1_char_bigram.html", null ],
      [ "tesseract::CharBigrams", "classtesseract_1_1_char_bigrams.html", null ],
      [ "tesseract::CharBigramTable", "structtesseract_1_1_char_bigram_table.html", null ],
      [ "tesseract::CharClassifier", "classtesseract_1_1_char_classifier.html", [
        [ "tesseract::ConvNetCharClassifier", "classtesseract_1_1_conv_net_char_classifier.html", null ],
        [ "tesseract::HybridNeuralNetCharClassifier", "classtesseract_1_1_hybrid_neural_net_char_classifier.html", null ]
      ] ],
      [ "tesseract::CharClassifierFactory", "classtesseract_1_1_char_classifier_factory.html", null ],
      [ "tesseract::CharSampEnum", "classtesseract_1_1_char_samp_enum.html", null ],
      [ "tesseract::CharSampSet", "classtesseract_1_1_char_samp_set.html", null ],
      [ "tesseract::CharSet", "classtesseract_1_1_char_set.html", null ],
      [ "CHISTRUCT", "struct_c_h_i_s_t_r_u_c_t.html", null ],
      [ "tesseract::ChoiceIterator", "classtesseract_1_1_choice_iterator.html", null ],
      [ "CHUNKS_RECORD", "struct_c_h_u_n_k_s___r_e_c_o_r_d.html", null ],
      [ "CLASS_STRUCT", "struct_c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "ClassPrunerData", "struct_class_pruner_data.html", null ],
      [ "CLIST", "class_c_l_i_s_t.html", null ],
      [ "CLIST_ITERATOR", "class_c_l_i_s_t___i_t_e_r_a_t_o_r.html", null ],
      [ "CLIST_LINK", "class_c_l_i_s_t___l_i_n_k.html", null ],
      [ "CLUSTERCONFIG", "struct_c_l_u_s_t_e_r_c_o_n_f_i_g.html", null ],
      [ "CLUSTERER", "struct_c_l_u_s_t_e_r_e_r.html", null ],
      [ "ClusteringContext", "struct_clustering_context.html", null ],
      [ "tesseract::ConComp", "classtesseract_1_1_con_comp.html", null ],
      [ "tesseract::ConCompPt", "classtesseract_1_1_con_comp_pt.html", null ],
      [ "CP_RESULT_STRUCT", "struct_c_p___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "CRACKEDGE", "class_c_r_a_c_k_e_d_g_e.html", null ],
      [ "CrackPos", "struct_crack_pos.html", null ],
      [ "tesseract::CubeLineObject", "classtesseract_1_1_cube_line_object.html", null ],
      [ "tesseract::CubeLineSegmenter", "classtesseract_1_1_cube_line_segmenter.html", null ],
      [ "tesseract::CubeObject", "classtesseract_1_1_cube_object.html", null ],
      [ "tesseract::CubeRecoContext", "classtesseract_1_1_cube_reco_context.html", null ],
      [ "tesseract::CubeUtils", "classtesseract_1_1_cube_utils.html", null ],
      [ "DANGERR_INFO", "struct_d_a_n_g_e_r_r___i_n_f_o.html", null ],
      [ "tesseract::Dawg", "classtesseract_1_1_dawg.html", [
        [ "tesseract::SquishedDawg", "classtesseract_1_1_squished_dawg.html", null ],
        [ "tesseract::Trie", "classtesseract_1_1_trie.html", null ]
      ] ],
      [ "tesseract::DawgArgs", "structtesseract_1_1_dawg_args.html", null ],
      [ "tesseract::DawgInfo", "structtesseract_1_1_dawg_info.html", null ],
      [ "DENORM", "class_d_e_n_o_r_m.html", null ],
      [ "DENORM_SEG", "class_d_e_n_o_r_m___s_e_g.html", null ],
      [ "tesseract::DetLineFit", "classtesseract_1_1_det_line_fit.html", null ],
      [ "tesseract::Dict", "classtesseract_1_1_dict.html", null ],
      [ "DIR128", "class_d_i_r128.html", null ],
      [ "tesseract::DocQualCallbacks", "structtesseract_1_1_doc_qual_callbacks.html", null ],
      [ "tesseract::DPPoint", "classtesseract_1_1_d_p_point.html", null ],
      [ "EANYCODE_CHAR", "struct_e_a_n_y_c_o_d_e___c_h_a_r.html", null ],
      [ "EDGEPT", "struct_e_d_g_e_p_t.html", null ],
      [ "EFONT_DESC", "struct_e_f_o_n_t___d_e_s_c.html", null ],
      [ "MinK< Key, Value >::Element", "struct_min_k_1_1_element.html", null ],
      [ "ELIST", "class_e_l_i_s_t.html", null ],
      [ "ELIST2", "class_e_l_i_s_t2.html", null ],
      [ "ELIST2_ITERATOR", "class_e_l_i_s_t2___i_t_e_r_a_t_o_r.html", null ],
      [ "ELIST2_LINK", "class_e_l_i_s_t2___l_i_n_k.html", [
        [ "tesseract::ColPartition", "classtesseract_1_1_col_partition.html", null ],
        [ "tesseract::TabVector", "classtesseract_1_1_tab_vector.html", null ],
        [ "TO_ROW", "class_t_o___r_o_w.html", null ],
        [ "WERD", "class_w_e_r_d.html", null ]
      ] ],
      [ "ELIST_ITERATOR", "class_e_l_i_s_t___i_t_e_r_a_t_o_r.html", null ],
      [ "ELIST_LINK", "class_e_l_i_s_t___l_i_n_k.html", [
        [ "BLOB_CHOICE", "class_b_l_o_b___c_h_o_i_c_e.html", null ],
        [ "BLOBNBOX", "class_b_l_o_b_n_b_o_x.html", null ],
        [ "BLOCK", "class_b_l_o_c_k.html", null ],
        [ "BLOCK_RES", "class_b_l_o_c_k___r_e_s.html", null ],
        [ "C_BLOB", "class_c___b_l_o_b.html", null ],
        [ "C_OUTLINE", "class_c___o_u_t_l_i_n_e.html", null ],
        [ "C_OUTLINE_FRAG", "class_c___o_u_t_l_i_n_e___f_r_a_g.html", null ],
        [ "FPSEGPT", "class_f_p_s_e_g_p_t.html", null ],
        [ "ICOORDELT", "class_i_c_o_o_r_d_e_l_t.html", null ],
        [ "ParamContent", "class_param_content.html", null ],
        [ "REGION_OCC", "class_r_e_g_i_o_n___o_c_c.html", null ],
        [ "ROW", "class_r_o_w.html", null ],
        [ "ROW_RES", "class_r_o_w___r_e_s.html", null ],
        [ "SEG_SEARCH_PENDING", "struct_s_e_g___s_e_a_r_c_h___p_e_n_d_i_n_g.html", null ],
        [ "SORTED_FLOAT", "class_s_o_r_t_e_d___f_l_o_a_t.html", null ],
        [ "tesseract::AmbigSpec", "classtesseract_1_1_ambig_spec.html", null ],
        [ "tesseract::ColPartitionSet", "classtesseract_1_1_col_partition_set.html", null ],
        [ "tesseract::ColSegment", "classtesseract_1_1_col_segment.html", null ],
        [ "tesseract::FRAGMENT", "classtesseract_1_1_f_r_a_g_m_e_n_t.html", null ],
        [ "tesseract::TabConstraint", "classtesseract_1_1_tab_constraint.html", null ],
        [ "tesseract::TESS_CHAR", "structtesseract_1_1_t_e_s_s___c_h_a_r.html", null ],
        [ "tesseract::ViterbiStateEntry", "structtesseract_1_1_viterbi_state_entry.html", null ],
        [ "tesseract::WorkingPartSet", "classtesseract_1_1_working_part_set.html", null ],
        [ "TO_BLOCK", "class_t_o___b_l_o_c_k.html", null ],
        [ "WERD_RES", "class_w_e_r_d___r_e_s.html", null ]
      ] ],
      [ "EOCR_DESC", "struct_e_o_c_r___d_e_s_c.html", null ],
      [ "ERRCODE", "class_e_r_r_c_o_d_e.html", null ],
      [ "ESTRIP_DESC", "struct_e_s_t_r_i_p___d_e_s_c.html", null ],
      [ "ETEXT_DESC", "class_e_t_e_x_t___d_e_s_c.html", null ],
      [ "EVALUATION_RECORD", "struct_e_v_a_l_u_a_t_i_o_n___r_e_c_o_r_d.html", null ],
      [ "EXPANDED_CHOICE", "struct_e_x_p_a_n_d_e_d___c_h_o_i_c_e.html", null ],
      [ "FCOORD", "class_f_c_o_o_r_d.html", null ],
      [ "FEATURE_DEFS_STRUCT", "struct_f_e_a_t_u_r_e___d_e_f_s___s_t_r_u_c_t.html", null ],
      [ "FEATURE_DESC_STRUCT", "struct_f_e_a_t_u_r_e___d_e_s_c___s_t_r_u_c_t.html", null ],
      [ "FEATURE_EXT_STRUCT", "struct_f_e_a_t_u_r_e___e_x_t___s_t_r_u_c_t.html", null ],
      [ "FEATURE_SET_STRUCT", "struct_f_e_a_t_u_r_e___s_e_t___s_t_r_u_c_t.html", null ],
      [ "FEATURE_STRUCT", "struct_f_e_a_t_u_r_e___s_t_r_u_c_t.html", null ],
      [ "tesseract::FeatureBase", "classtesseract_1_1_feature_base.html", [
        [ "tesseract::FeatureBmp", "classtesseract_1_1_feature_bmp.html", null ],
        [ "tesseract::FeatureChebyshev", "classtesseract_1_1_feature_chebyshev.html", null ],
        [ "tesseract::FeatureHybrid", "classtesseract_1_1_feature_hybrid.html", null ]
      ] ],
      [ "FILL_SPEC", "struct_f_i_l_l___s_p_e_c.html", null ],
      [ "FILL_SWITCH", "struct_f_i_l_l___s_w_i_t_c_h.html", null ],
      [ "FLOATUNION", "union_f_l_o_a_t_u_n_i_o_n.html", null ],
      [ "FontInfo", "struct_font_info.html", null ],
      [ "tesseract::FontPairSizeInfo", "structtesseract_1_1_font_pair_size_info.html", null ],
      [ "FontSet", "struct_font_set.html", null ],
      [ "FontSpacingInfo", "struct_font_spacing_info.html", null ],
      [ "FPCUTPT", "class_f_p_c_u_t_p_t.html", null ],
      [ "FPOINT", "struct_f_p_o_i_n_t.html", null ],
      [ "FRECT", "struct_f_r_e_c_t.html", null ],
      [ "FREE_CALL", "class_f_r_e_e___c_a_l_l.html", null ],
      [ "GAPMAP", "class_g_a_p_m_a_p.html", null ],
      [ "GENERIC_2D_ARRAY< T >", "class_g_e_n_e_r_i_c__2_d___a_r_r_a_y.html", [
        [ "GENERIC_MATRIX< T >", "class_g_e_n_e_r_i_c___m_a_t_r_i_x.html", null ]
      ] ],
      [ "GENERIC_2D_ARRAY< BLOB_CHOICE_LIST * >", "class_g_e_n_e_r_i_c__2_d___a_r_r_a_y.html", [
        [ "GENERIC_MATRIX< BLOB_CHOICE_LIST * >", "class_g_e_n_e_r_i_c___m_a_t_r_i_x.html", [
          [ "MATRIX", "class_m_a_t_r_i_x.html", null ]
        ] ]
      ] ],
      [ "GenericVector< T >", "class_generic_vector.html", [
        [ "GenericVectorEqEq< T >", "class_generic_vector_eq_eq.html", null ]
      ] ],
      [ "GenericVector< DawgInfo >", "class_generic_vector.html", [
        [ "tesseract::DawgInfoVector", "classtesseract_1_1_dawg_info_vector.html", null ]
      ] ],
      [ "GenericVector< T * >", "class_generic_vector.html", [
        [ "tesseract::PointerVector< T >", "classtesseract_1_1_pointer_vector.html", null ]
      ] ],
      [ "tesseract::GridBase", "classtesseract_1_1_grid_base.html", [
        [ "tesseract::BBGrid< BLOBNBOX, BLOBNBOX_CLIST, BLOBNBOX_C_IT >", "classtesseract_1_1_b_b_grid.html", [
          [ "tesseract::AlignedBlob", "classtesseract_1_1_aligned_blob.html", [
            [ "tesseract::TabFind", "classtesseract_1_1_tab_find.html", [
              [ "tesseract::ColumnFinder", "classtesseract_1_1_column_finder.html", null ]
            ] ]
          ] ],
          [ "tesseract::StrokeWidth", "classtesseract_1_1_stroke_width.html", null ]
        ] ],
        [ "tesseract::BBGrid< ColPartition, ColPartition_CLIST, ColPartition_C_IT >", "classtesseract_1_1_b_b_grid.html", [
          [ "tesseract::ColPartitionGrid", "classtesseract_1_1_col_partition_grid.html", null ]
        ] ],
        [ "tesseract::BBGrid< BBC, BBC_CLIST, BBC_C_IT >", "classtesseract_1_1_b_b_grid.html", null ],
        [ "tesseract::IntGrid", "classtesseract_1_1_int_grid.html", null ]
      ] ],
      [ "tesseract::GridSearch< BBC, BBC_CLIST, BBC_C_IT >", "classtesseract_1_1_grid_search.html", null ],
      [ "HEAP", "struct_h_e_a_p.html", null ],
      [ "HEAPENTRY", "struct_h_e_a_p_e_n_t_r_y.html", null ],
      [ "ICOORD", "class_i_c_o_o_r_d.html", [
        [ "ICOORDELT", "class_i_c_o_o_r_d_e_l_t.html", null ]
      ] ],
      [ "Identity< T >", "struct_identity.html", null ],
      [ "tesseract::Image", "classtesseract_1_1_image.html", null ],
      [ "IMAGE", "class_i_m_a_g_e.html", null ],
      [ "tesseract::ImageFinder", "classtesseract_1_1_image_finder.html", null ],
      [ "IMAGELINE", "class_i_m_a_g_e_l_i_n_e.html", null ],
      [ "tesseract::ImageThresholder", "classtesseract_1_1_image_thresholder.html", null ],
      [ "tesseract::InputFileBuffer", "classtesseract_1_1_input_file_buffer.html", null ],
      [ "INT_CLASS_STRUCT", "struct_i_n_t___c_l_a_s_s___s_t_r_u_c_t.html", null ],
      [ "INT_FEATURE_STRUCT", "struct_i_n_t___f_e_a_t_u_r_e___s_t_r_u_c_t.html", null ],
      [ "INT_FX_RESULT_STRUCT", "struct_i_n_t___f_x___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "INT_PROTO_STRUCT", "struct_i_n_t___p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "INT_RESULT_STRUCT", "struct_i_n_t___r_e_s_u_l_t___s_t_r_u_c_t.html", null ],
      [ "INT_TEMPLATES_STRUCT", "struct_i_n_t___t_e_m_p_l_a_t_e_s___s_t_r_u_c_t.html", null ],
      [ "IntegerMatcher", "class_integer_matcher.html", null ],
      [ "KDNODE", "struct_k_d_n_o_d_e.html", null ],
      [ "KDTREE", "struct_k_d_t_r_e_e.html", null ],
      [ "KDTreeSearch", "class_k_d_tree_search.html", null ],
      [ "LABELEDLISTNODE", "struct_l_a_b_e_l_e_d_l_i_s_t_n_o_d_e.html", null ],
      [ "tesseract::LangModEdge", "classtesseract_1_1_lang_mod_edge.html", [
        [ "tesseract::TessLangModEdge", "classtesseract_1_1_tess_lang_mod_edge.html", null ]
      ] ],
      [ "tesseract::LangModel", "classtesseract_1_1_lang_model.html", [
        [ "tesseract::TessLangModel", "classtesseract_1_1_tess_lang_model.html", null ],
        [ "tesseract::WordListLangModel", "classtesseract_1_1_word_list_lang_model.html", null ]
      ] ],
      [ "tesseract::LanguageModel", "classtesseract_1_1_language_model.html", null ],
      [ "tesseract::LanguageModelConsistencyInfo", "structtesseract_1_1_language_model_consistency_info.html", null ],
      [ "tesseract::LanguageModelDawgInfo", "structtesseract_1_1_language_model_dawg_info.html", null ],
      [ "tesseract::LanguageModelNgramInfo", "structtesseract_1_1_language_model_ngram_info.html", null ],
      [ "tesseract::LanguageModelState", "structtesseract_1_1_language_model_state.html", null ],
      [ "tesseract::LineFinder", "classtesseract_1_1_line_finder.html", null ],
      [ "list_rec", "structlist__rec.html", null ],
      [ "LLSQ", "class_l_l_s_q.html", null ],
      [ "MALLOC_CALL", "class_m_a_l_l_o_c___c_a_l_l.html", null ],
      [ "MATCH_RESULT", "struct_m_a_t_c_h___r_e_s_u_l_t.html", null ],
      [ "MATRIX_2D", "struct_m_a_t_r_i_x__2_d.html", null ],
      [ "MATRIX_COORD", "struct_m_a_t_r_i_x___c_o_o_r_d.html", null ],
      [ "MEASUREMENT", "struct_m_e_a_s_u_r_e_m_e_n_t.html", null ],
      [ "MEM_ALLOCATOR", "class_m_e_m___a_l_l_o_c_a_t_o_r.html", null ],
      [ "MEMBLOCK", "class_m_e_m_b_l_o_c_k.html", null ],
      [ "MEMUNION", "class_m_e_m_u_n_i_o_n.html", null ],
      [ "MERGE_CLASS_NODE", "struct_m_e_r_g_e___c_l_a_s_s___n_o_d_e.html", null ],
      [ "MFEDGEPT", "struct_m_f_e_d_g_e_p_t.html", null ],
      [ "MinK< Key, Value >", "class_min_k.html", null ],
      [ "tesseract::NeuralNet", "classtesseract_1_1_neural_net.html", null ],
      [ "tesseract::Neuron", "classtesseract_1_1_neuron.html", null ],
      [ "tesseract::NeuralNet::Node", "structtesseract_1_1_neural_net_1_1_node.html", null ],
      [ "tesseract::NodeChild", "structtesseract_1_1_node_child.html", null ],
      [ "NORM_PROTOS", "struct_n_o_r_m___p_r_o_t_o_s.html", null ],
      [ "OL_BUCKETS", "class_o_l___b_u_c_k_e_t_s.html", null ],
      [ "OrientationDetector", "class_orientation_detector.html", null ],
      [ "OSBestResult", "struct_o_s_best_result.html", null ],
      [ "OSResults", "struct_o_s_results.html", null ],
      [ "OUTLINE_STATS", "struct_o_u_t_l_i_n_e___s_t_a_t_s.html", null ],
      [ "PAGE_RES", "class_p_a_g_e___r_e_s.html", null ],
      [ "PAGE_RES_IT", "class_p_a_g_e___r_e_s___i_t.html", null ],
      [ "tesseract::PageIterator", "classtesseract_1_1_page_iterator.html", [
        [ "tesseract::ResultIterator", "classtesseract_1_1_result_iterator.html", null ]
      ] ],
      [ "tesseract::PairSizeInfo", "structtesseract_1_1_pair_size_info.html", null ],
      [ "tesseract::Param", "classtesseract_1_1_param.html", [
        [ "tesseract::BoolParam", "classtesseract_1_1_bool_param.html", null ],
        [ "tesseract::DoubleParam", "classtesseract_1_1_double_param.html", null ],
        [ "tesseract::IntParam", "classtesseract_1_1_int_param.html", null ],
        [ "tesseract::StringParam", "classtesseract_1_1_string_param.html", null ]
      ] ],
      [ "PARAM_DESC", "struct_p_a_r_a_m___d_e_s_c.html", null ],
      [ "tesseract::ParamsVectors", "structtesseract_1_1_params_vectors.html", null ],
      [ "tesseract::ParamUtils", "classtesseract_1_1_param_utils.html", null ],
      [ "PB_LINE_IT", "class_p_b___l_i_n_e___i_t.html", null ],
      [ "PDBLK", "class_p_d_b_l_k.html", [
        [ "BLOCK", "class_b_l_o_c_k.html", null ]
      ] ],
      [ "PERM_CONFIG_STRUCT", "struct_p_e_r_m___c_o_n_f_i_g___s_t_r_u_c_t.html", null ],
      [ "tesseract::PermuterState", "classtesseract_1_1_permuter_state.html", null ],
      [ "tesseract::PixelHistogram", "classtesseract_1_1_pixel_histogram.html", null ],
      [ "POLY_BLOCK", "class_p_o_l_y___b_l_o_c_k.html", null ],
      [ "PROTO_KEY", "struct_p_r_o_t_o___k_e_y.html", null ],
      [ "PROTO_SET_STRUCT", "struct_p_r_o_t_o___s_e_t___s_t_r_u_c_t.html", null ],
      [ "PROTO_STRUCT", "struct_p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "PROTOTYPE", "struct_p_r_o_t_o_t_y_p_e.html", null ],
      [ "QLSQ", "class_q_l_s_q.html", null ],
      [ "QRSequenceGenerator", "class_q_r_sequence_generator.html", null ],
      [ "QSPLINE", "class_q_s_p_l_i_n_e.html", null ],
      [ "QUAD_COEFFS", "class_q_u_a_d___c_o_e_f_f_s.html", null ],
      [ "REJ", "class_r_e_j.html", null ],
      [ "REJMAP", "class_r_e_j_m_a_p.html", null ],
      [ "remove_reference< T >", "structremove__reference.html", null ],
      [ "remove_reference< T & >", "structremove__reference_3_01_t_01_6_01_4.html", null ],
      [ "sample", "structsample.html", null ],
      [ "SAMPLELIST", "struct_s_a_m_p_l_e_l_i_s_t.html", null ],
      [ "ScoredClass", "struct_scored_class.html", null ],
      [ "ScratchEvidence", "struct_scratch_evidence.html", null ],
      [ "ScriptDetector", "class_script_detector.html", null ],
      [ "com::google::scrollview::ScrollView", "classcom_1_1google_1_1scrollview_1_1_scroll_view.html", null ],
      [ "ScrollView", "class_scroll_view.html", null ],
      [ "seam_record", "structseam__record.html", null ],
      [ "SEARCH_RECORD", "struct_s_e_a_r_c_h___r_e_c_o_r_d.html", null ],
      [ "tesseract::SearchColumn", "classtesseract_1_1_search_column.html", null ],
      [ "tesseract::SearchNode", "classtesseract_1_1_search_node.html", null ],
      [ "tesseract::SearchNodeHashTable", "classtesseract_1_1_search_node_hash_table.html", null ],
      [ "tesseract::SearchObject", "classtesseract_1_1_search_object.html", [
        [ "tesseract::CubeSearchObject", "classtesseract_1_1_cube_search_object.html", null ]
      ] ],
      [ "tesseract::ShiroRekhaSplitter", "classtesseract_1_1_shiro_rekha_splitter.html", null ],
      [ "SORTED_FLOATS", "class_s_o_r_t_e_d___f_l_o_a_t_s.html", null ],
      [ "SortHelper< T >", "class_sort_helper.html", null ],
      [ "SortHelper< T >::SortPair< PairT >", "struct_sort_helper_1_1_sort_pair.html", null ],
      [ "split_record", "structsplit__record.html", null ],
      [ "STATE", "struct_s_t_a_t_e.html", null ],
      [ "STATISTICS", "struct_s_t_a_t_i_s_t_i_c_s.html", null ],
      [ "STATS", "class_s_t_a_t_s.html", null ],
      [ "STRING", "class_s_t_r_i_n_g.html", null ],
      [ "tesseract::StructuredTable", "classtesseract_1_1_structured_table.html", null ],
      [ "com::google::scrollview::ui::SVAbstractMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_abstract_menu_item.html", [
        [ "com::google::scrollview::ui::SVCheckboxMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_checkbox_menu_item.html", null ],
        [ "com::google::scrollview::ui::SVEmptyMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_empty_menu_item.html", null ],
        [ "com::google::scrollview::ui::SVMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_menu_item.html", null ],
        [ "com::google::scrollview::ui::SVSubMenuItem", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_sub_menu_item.html", null ]
      ] ],
      [ "com::google::scrollview::events::SVEvent", "classcom_1_1google_1_1scrollview_1_1events_1_1_s_v_event.html", null ],
      [ "SVEvent", "struct_s_v_event.html", null ],
      [ "com::google::scrollview::events::SVEventHandler", "classcom_1_1google_1_1scrollview_1_1events_1_1_s_v_event_handler.html", null ],
      [ "SVEventHandler", "class_s_v_event_handler.html", [
        [ "BlnEventHandler", "class_bln_event_handler.html", null ],
        [ "ParamsEditor", "class_params_editor.html", null ],
        [ "PGEventHandler", "class_p_g_event_handler.html", null ],
        [ "SVPaint", "class_s_v_paint.html", null ],
        [ "tesseract::TabEventHandler< G >", "classtesseract_1_1_tab_event_handler.html", null ]
      ] ],
      [ "com::google::scrollview::ui::SVImageHandler", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_image_handler.html", null ],
      [ "com::google::scrollview::ui::SVMenuBar", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_menu_bar.html", null ],
      [ "SVMenuNode", "class_s_v_menu_node.html", null ],
      [ "SVMutex", "class_s_v_mutex.html", null ],
      [ "SVNetwork", "class_s_v_network.html", null ],
      [ "SVPolyLineBuffer", "struct_s_v_poly_line_buffer.html", null ],
      [ "com::google::scrollview::ui::SVPopupMenu", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_popup_menu.html", null ],
      [ "SVSemaphore", "class_s_v_semaphore.html", null ],
      [ "SVSync", "class_s_v_sync.html", null ],
      [ "com::google::scrollview::ui::SVWindow", "classcom_1_1google_1_1scrollview_1_1ui_1_1_s_v_window.html", null ],
      [ "TABLE_FILLER", "struct_t_a_b_l_e___f_i_l_l_e_r.html", null ],
      [ "tesseract::TableFinder", "classtesseract_1_1_table_finder.html", null ],
      [ "tesseract::TableRecognizer", "classtesseract_1_1_table_recognizer.html", null ],
      [ "TBLOB", "struct_t_b_l_o_b.html", null ],
      [ "TBOX", "class_t_b_o_x.html", null ],
      [ "TEMP_CONFIG_STRUCT", "struct_t_e_m_p___c_o_n_f_i_g___s_t_r_u_c_t.html", null ],
      [ "TEMP_PROTO_STRUCT", "struct_t_e_m_p___p_r_o_t_o___s_t_r_u_c_t.html", null ],
      [ "TEMPCLUSTER", "struct_t_e_m_p_c_l_u_s_t_e_r.html", null ],
      [ "tesseract::TessBaseAPI", "classtesseract_1_1_tess_base_a_p_i.html", null ],
      [ "TessCallback1< A1 >", "class_tess_callback1.html", [
        [ "_ConstTessMemberResultCallback_0_1< del, void, T, A1 >", "class___const_tess_member_result_callback__0__1_3_01del_00_01void_00_01_t_00_01_a1_01_4.html", null ],
        [ "_TessFunctionResultCallback_0_1< del, void, A1 >", "class___tess_function_result_callback__0__1_3_01del_00_01void_00_01_a1_01_4.html", null ],
        [ "_TessMemberResultCallback_0_1< del, void, T, A1 >", "class___tess_member_result_callback__0__1_3_01del_00_01void_00_01_t_00_01_a1_01_4.html", null ]
      ] ],
      [ "TessCallback1< DawgInfo >", "class_tess_callback1.html", null ],
      [ "TessCallback1< T * >", "class_tess_callback1.html", null ],
      [ "TessCallback2< A1, A2 >", "class_tess_callback2.html", [
        [ "_ConstTessMemberResultCallback_0_2< del, void, T, A1, A2 >", "class___const_tess_member_result_callback__0__2_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_01_4.html", null ],
        [ "_ConstTessMemberResultCallback_1_2< del, void, T, P1, A1, A2 >", "class___const_tess_member_result_callback__1__2_3_01del_00_01void_00_01_t_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ],
        [ "_TessFunctionResultCallback_0_2< del, void, A1, A2 >", "class___tess_function_result_callback__0__2_3_01del_00_01void_00_01_a1_00_01_a2_01_4.html", null ],
        [ "_TessFunctionResultCallback_1_2< del, R, P1, A1, A2 >", "class___tess_function_result_callback__1__2.html", null ],
        [ "_TessFunctionResultCallback_1_2< del, void, P1, A1, A2 >", "class___tess_function_result_callback__1__2_3_01del_00_01void_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ],
        [ "_TessMemberResultCallback_0_2< del, void, T, A1, A2 >", "class___tess_member_result_callback__0__2_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_01_4.html", null ],
        [ "_TessMemberResultCallback_1_2< del, void, T, P1, A1, A2 >", "class___tess_member_result_callback__1__2_3_01del_00_01void_00_01_t_00_01_p1_00_01_a1_00_01_a2_01_4.html", null ]
      ] ],
      [ "TessCallback3< A1, A2, A3 >", "class_tess_callback3.html", [
        [ "_ConstTessMemberResultCallback_0_3< del, void, T, A1, A2, A3 >", "class___const_tess_member_result_callback__0__3_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ],
        [ "_TessFunctionResultCallback_0_3< del, void, A1, A2, A3 >", "class___tess_function_result_callback__0__3_3_01del_00_01void_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ],
        [ "_TessMemberResultCallback_0_3< del, void, T, A1, A2, A3 >", "class___tess_member_result_callback__0__3_3_01del_00_01void_00_01_t_00_01_a1_00_01_a2_00_01_a3_01_4.html", null ]
      ] ],
      [ "TessCallbackUtils_", "struct_tess_callback_utils__.html", null ],
      [ "TessClosure", "class_tess_closure.html", [
        [ "_ConstTessMemberResultCallback_0_0< del, void, T >", "class___const_tess_member_result_callback__0__0_3_01del_00_01void_00_01_t_01_4.html", null ],
        [ "_TessFunctionResultCallback_0_0< del, void >", "class___tess_function_result_callback__0__0_3_01del_00_01void_01_4.html", null ],
        [ "_TessMemberResultCallback_0_0< del, void, T >", "class___tess_member_result_callback__0__0_3_01del_00_01void_00_01_t_01_4.html", null ]
      ] ],
      [ "tesseract::TessdataManager", "classtesseract_1_1_tessdata_manager.html", null ],
      [ "tesseract::TesseractCubeCombiner", "classtesseract_1_1_tesseract_cube_combiner.html", null ],
      [ "tesseract::TesseractStats", "structtesseract_1_1_tesseract_stats.html", null ],
      [ "TESSLINE", "struct_t_e_s_s_l_i_n_e.html", null ],
      [ "TessResultCallback< R >", "class_tess_result_callback.html", [
        [ "_ConstTessMemberResultCallback_0_0< del, R, T >", "class___const_tess_member_result_callback__0__0.html", null ],
        [ "_TessFunctionResultCallback_0_0< del, R >", "class___tess_function_result_callback__0__0.html", null ],
        [ "_TessMemberResultCallback_0_0< del, R, T >", "class___tess_member_result_callback__0__0.html", null ]
      ] ],
      [ "TessResultCallback1< R, A1 >", "class_tess_result_callback1.html", [
        [ "_ConstTessMemberResultCallback_0_1< del, R, T, A1 >", "class___const_tess_member_result_callback__0__1.html", null ],
        [ "_TessFunctionResultCallback_0_1< del, R, A1 >", "class___tess_function_result_callback__0__1.html", null ],
        [ "_TessMemberResultCallback_0_1< del, R, T, A1 >", "class___tess_member_result_callback__0__1.html", null ]
      ] ],
      [ "TessResultCallback2< R, A1, A2 >", "class_tess_result_callback2.html", [
        [ "_ConstTessMemberResultCallback_0_2< del, R, T, A1, A2 >", "class___const_tess_member_result_callback__0__2.html", null ],
        [ "_ConstTessMemberResultCallback_1_2< del, R, T, P1, A1, A2 >", "class___const_tess_member_result_callback__1__2.html", null ],
        [ "_TessFunctionResultCallback_0_2< del, R, A1, A2 >", "class___tess_function_result_callback__0__2.html", null ],
        [ "_TessMemberResultCallback_0_2< del, R, T, A1, A2 >", "class___tess_member_result_callback__0__2.html", null ],
        [ "_TessMemberResultCallback_1_2< del, R, T, P1, A1, A2 >", "class___tess_member_result_callback__1__2.html", null ]
      ] ],
      [ "TessResultCallback2< bool, DawgInfoconst &, DawgInfoconst & >", "class_tess_result_callback2.html", null ],
      [ "TessResultCallback2< bool, T *const &, T *const & >", "class_tess_result_callback2.html", null ],
      [ "TessResultCallback3< R, A1, A2, A3 >", "class_tess_result_callback3.html", [
        [ "_ConstTessMemberResultCallback_0_3< del, R, T, A1, A2, A3 >", "class___const_tess_member_result_callback__0__3.html", null ],
        [ "_TessFunctionResultCallback_0_3< del, R, A1, A2, A3 >", "class___tess_function_result_callback__0__3.html", null ],
        [ "_TessMemberResultCallback_0_3< del, R, T, A1, A2, A3 >", "class___tess_member_result_callback__0__3.html", null ]
      ] ],
      [ "tesseract::Textord", "classtesseract_1_1_textord.html", null ],
      [ "TIFFENTRY", "struct_t_i_f_f_e_n_t_r_y.html", null ],
      [ "TPOINT", "struct_t_p_o_i_n_t.html", null ],
      [ "TRIE_NODE_RECORD", "struct_t_r_i_e___n_o_d_e___r_e_c_o_r_d.html", null ],
      [ "tesseract::TuningParams", "classtesseract_1_1_tuning_params.html", [
        [ "tesseract::CubeTuningParams", "classtesseract_1_1_cube_tuning_params.html", null ]
      ] ],
      [ "TWERD", "struct_t_w_e_r_d.html", null ],
      [ "UNICHAR", "class_u_n_i_c_h_a_r.html", null ],
      [ "tesseract::UnicharAmbigs", "classtesseract_1_1_unichar_ambigs.html", null ],
      [ "tesseract::UnicharIdArrayUtils", "classtesseract_1_1_unichar_id_array_utils.html", null ],
      [ "UNICHARMAP", "class_u_n_i_c_h_a_r_m_a_p.html", null ],
      [ "UNICHARSET", "class_u_n_i_c_h_a_r_s_e_t.html", null ],
      [ "UnicityTable< T >", "class_unicity_table.html", [
        [ "UnicityTableEqEq< T >", "class_unicity_table_eq_eq.html", null ]
      ] ],
      [ "UWREC", "class_u_w_r_e_c.html", null ],
      [ "VIABLE_CHOICE_STRUCT", "struct_v_i_a_b_l_e___c_h_o_i_c_e___s_t_r_u_c_t.html", null ],
      [ "tesseract::NeuralNet::WeightedNode", "structtesseract_1_1_neural_net_1_1_weighted_node.html", null ],
      [ "WERD_CHOICE", "class_w_e_r_d___c_h_o_i_c_e.html", null ],
      [ "WIDTH_RECORD", "struct_w_i_d_t_h___r_e_c_o_r_d.html", null ],
      [ "tesseract::WordSizeModel", "classtesseract_1_1_word_size_model.html", null ],
      [ "tesseract::WordUnigrams", "classtesseract_1_1_word_unigrams.html", null ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "Namespace List", "namespaces.html", [
      [ "com", "namespacecom.html", null ],
      [ "com::google", "namespacecom_1_1google.html", null ],
      [ "com::google::scrollview", "namespacecom_1_1google_1_1scrollview.html", null ],
      [ "com::google::scrollview::events", "namespacecom_1_1google_1_1scrollview_1_1events.html", null ],
      [ "com::google::scrollview::ui", "namespacecom_1_1google_1_1scrollview_1_1ui.html", null ],
      [ "tesseract", "namespacetesseract.html", null ]
    ] ],
    [ "Namespace Members", "namespacemembers.html", null ],
    [ "File List", "files.html", [
      [ "/data/source/tesseract-ocr/config_auto.h", "config__auto_8h.html", null ],
      [ "/data/source/tesseract-ocr/api/apitypes.h", "apitypes_8h.html", null ],
      [ "/data/source/tesseract-ocr/api/baseapi.cpp", "baseapi_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/api/baseapi.h", "baseapi_8h.html", null ],
      [ "/data/source/tesseract-ocr/api/pageiterator.cpp", "pageiterator_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/api/pageiterator.h", "pageiterator_8h.html", null ],
      [ "/data/source/tesseract-ocr/api/resultiterator.cpp", "resultiterator_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/api/resultiterator.h", "resultiterator_8h.html", null ],
      [ "/data/source/tesseract-ocr/api/tesseractmain.cpp", "tesseractmain_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/api/tesseractmain.h", "tesseractmain_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/adaptions.cpp", "adaptions_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/applybox.cpp", "applybox_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/control.cpp", "control_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/control.h", "control_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/cube_control.cpp", "cube__control_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/cube_reco_context.cpp", "cube__reco__context_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/cube_reco_context.h", "cube__reco__context_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/docqual.cpp", "docqual_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/docqual.h", "docqual_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/fixspace.cpp", "fixspace_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/fixspace.h", "fixspace_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/fixxht.cpp", "fixxht_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/imgscale.cpp", "imgscale_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/imgscale.h", "imgscale_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/osdetect.cpp", "osdetect_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/osdetect.h", "osdetect_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/output.cpp", "output_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/output.h", "output_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/pagesegmain.cpp", "pagesegmain_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/pagewalk.cpp", "pagewalk_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/paramsd.cpp", "paramsd_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/paramsd.h", "paramsd_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/pgedit.cpp", "pgedit_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/pgedit.h", "pgedit_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/recogtraining.cpp", "recogtraining_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/reject.cpp", "reject_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/reject.h", "reject_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/scaleimg.cpp", "scaleimg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/scaleimg.h", "scaleimg_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessbox.cpp", "tessbox_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessbox.h", "tessbox_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessedit.cpp", "tessedit_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessedit.h", "tessedit_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tesseract_cube_combiner.cpp", "tesseract__cube__combiner_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tesseract_cube_combiner.h", "tesseract__cube__combiner_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tesseractclass.cpp", "tesseractclass_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tesseractclass.h", "tesseractclass_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessvars.cpp", "tessvars_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tessvars.h", "tessvars_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tfacep.h", "tfacep_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tfacepp.cpp", "tfacepp_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/tfacepp.h", "tfacepp_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/thresholder.cpp", "thresholder_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/thresholder.h", "thresholder_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/werdit.cpp", "werdit_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccmain/werdit.h", "werdit_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blckerr.h", "blckerr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blobbox.cpp", "blobbox_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blobbox.h", "blobbox_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blobs.cpp", "blobs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blobs.h", "blobs_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blread.cpp", "blread_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/blread.h", "blread_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/boxword.cpp", "boxword_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/boxword.h", "boxword_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ccstruct.cpp", "ccstruct_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ccstruct.h", "ccstruct_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/coutln.cpp", "coutln_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/coutln.h", "coutln_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/crakedge.h", "crakedge_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/detlinefit.cpp", "detlinefit_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/detlinefit.h", "detlinefit_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/dppoint.cpp", "dppoint_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/dppoint.h", "dppoint_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/genblob.cpp", "genblob_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/genblob.h", "genblob_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/hpddef.h", "hpddef_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/hpdsizes.h", "hpdsizes_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ipoints.h", "ipoints_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/linlsq.cpp", "linlsq_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/linlsq.h", "linlsq_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/matrix.cpp", "matrix_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/matrix.h", "matrix_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/mod128.cpp", "mod128_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/mod128.h", "mod128_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/normalis.cpp", "normalis_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/normalis.h", "normalis_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ocrblock.cpp", "ocrblock_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ocrblock.h", "ocrblock_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ocrrow.cpp", "ocrrow_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ocrrow.h", "ocrrow_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/otsuthr.cpp", "otsuthr_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/otsuthr.h", "otsuthr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/pageres.cpp", "pageres_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/pageres.h", "pageres_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/pdblock.cpp", "pdblock_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/pdblock.h", "pdblock_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/points.cpp", "points_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/points.h", "points_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/polyaprx.cpp", "polyaprx_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/polyaprx.h", "polyaprx_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/polyblk.cpp", "polyblk_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/polyblk.h", "polyblk_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/publictypes.cpp", "publictypes_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/publictypes.h", "publictypes_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quadlsq.cpp", "quadlsq_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quadlsq.h", "quadlsq_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quadratc.cpp", "quadratc_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quadratc.h", "quadratc_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quspline.cpp", "quspline_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/quspline.h", "quspline_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ratngs.cpp", "ratngs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/ratngs.h", "ratngs_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/rect.cpp", "rect_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/rect.h", "rect_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/rejctmap.cpp", "rejctmap_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/rejctmap.h", "rejctmap_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/seam.cpp", "seam_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/seam.h", "seam_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/split.cpp", "split_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/split.h", "split_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/statistc.cpp", "statistc_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/statistc.h", "statistc_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/stepblob.cpp", "stepblob_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/stepblob.h", "stepblob_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/vecfuncs.cpp", "vecfuncs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/vecfuncs.h", "vecfuncs_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/werd.cpp", "werd_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccstruct/werd.h", "werd_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ambigs.cpp", "ambigs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ambigs.h", "ambigs_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/basedir.cpp", "basedir_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/basedir.h", "basedir_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/bits16.cpp", "bits16_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/bits16.h", "bits16_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/boxread.cpp", "boxread_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/boxread.h", "boxread_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ccutil.cpp", "ccutil_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ccutil.h", "ccutil_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/clst.cpp", "clst_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/clst.h", "clst_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/elst.cpp", "elst_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/elst.h", "elst_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/elst2.cpp", "elst2_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/elst2.h", "elst2_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/errcode.cpp", "errcode_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/errcode.h", "errcode_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/fileerr.h", "fileerr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/genericvector.h", "genericvector_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/globaloc.cpp", "globaloc_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/globaloc.h", "globaloc_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/hashfn.cpp", "hashfn_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/hashfn.h", "hashfn_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/helpers.h", "helpers_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/host.h", "host_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/hosthplb.h", "hosthplb_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/lsterr.h", "lsterr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/mainblk.cpp", "mainblk_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/memblk.cpp", "memblk_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/memblk.h", "memblk_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/memry.cpp", "memry_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/memry.h", "memry_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/memryerr.h", "memryerr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/mfcpch.cpp", "mfcpch_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/mfcpch.h", "mfcpch_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ndminx.h", "ndminx_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/notdll.h", "notdll_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/nwmain.h", "nwmain_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/ocrclass.h", "ocrclass_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/params.cpp", "params_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/params.h", "params_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/platform.h", "platform_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/qrsequence.h", "qrsequence_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/scanutils.cpp", "scanutils_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/scanutils.h", "scanutils_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/secname.h", "secname_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/serialis.cpp", "serialis_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/serialis.h", "serialis_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/sorthelper.h", "sorthelper_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/stderr.h", "stderr_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/strngs.cpp", "strngs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/strngs.h", "strngs_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/tesscallback.h", "tesscallback_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/tessdatamanager.cpp", "tessdatamanager_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/tessdatamanager.h", "tessdatamanager_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/tprintf.cpp", "tprintf_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/tprintf.h", "tprintf_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unichar.cpp", "unichar_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unichar.h", "unichar_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unicharmap.cpp", "unicharmap_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unicharmap.h", "unicharmap_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unicharset.cpp", "unicharset_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unicharset.h", "unicharset_8h.html", null ],
      [ "/data/source/tesseract-ocr/ccutil/unicity_table.h", "unicity__table_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/adaptive.cpp", "adaptive_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/adaptive.h", "adaptive_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/adaptmatch.cpp", "adaptmatch_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/baseline.h", "baseline_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/blobclass.cpp", "blobclass_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/blobclass.h", "blobclass_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/chartoname.cpp", "chartoname_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/chartoname.h", "chartoname_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/classify.cpp", "classify_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/classify.h", "classify_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/cluster.cpp", "cluster_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/cluster.h", "cluster_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/clusttool.cpp", "clusttool_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/clusttool.h", "clusttool_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/cutoffs.cpp", "cutoffs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/cutoffs.h", "cutoffs_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/extern.h", "extern_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/extract.cpp", "extract_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/extract.h", "extract_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/featdefs.cpp", "featdefs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/featdefs.h", "featdefs_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/flexfx.cpp", "flexfx_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/flexfx.h", "flexfx_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/float2int.cpp", "float2int_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/float2int.h", "float2int_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/fpoint.cpp", "fpoint_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/fpoint.h", "fpoint_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/fxdefs.cpp", "fxdefs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/fxdefs.h", "fxdefs_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/intfx.cpp", "intfx_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/intfx.h", "intfx_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/intmatcher.cpp", "intmatcher_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/intmatcher.h", "intmatcher_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/intproto.cpp", "intproto_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/intproto.h", "intproto_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/kdtree.cpp", "kdtree_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/kdtree.h", "kdtree_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/mf.cpp", "mf_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/mf.h", "mf_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfdefs.cpp", "mfdefs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfdefs.h", "mfdefs_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfoutline.cpp", "mfoutline_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfoutline.h", "mfoutline_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfx.cpp", "mfx_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/mfx.h", "mfx_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/normfeat.cpp", "normfeat_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/normfeat.h", "normfeat_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/normmatch.cpp", "normmatch_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/normmatch.h", "normmatch_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/ocrfeatures.cpp", "ocrfeatures_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/ocrfeatures.h", "ocrfeatures_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/outfeat.cpp", "outfeat_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/outfeat.h", "outfeat_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/picofeat.cpp", "picofeat_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/picofeat.h", "picofeat_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/protos.cpp", "protos_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/protos.h", "protos_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/speckle.cpp", "speckle_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/speckle.h", "speckle_8h.html", null ],
      [ "/data/source/tesseract-ocr/classify/xform2d.cpp", "xform2d_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/classify/xform2d.h", "xform2d_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/altlist.cpp", "altlist_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/altlist.h", "altlist_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/beam_search.cpp", "beam__search_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/beam_search.h", "beam__search_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/bmp_8.cpp", "bmp__8_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/bmp_8.h", "bmp__8_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cached_file.cpp", "cached__file_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cached_file.h", "cached__file_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_altlist.cpp", "char__altlist_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_altlist.h", "char__altlist_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_bigrams.cpp", "char__bigrams_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_bigrams.h", "char__bigrams_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp.cpp", "char__samp_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp.h", "char__samp_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp_enum.cpp", "char__samp__enum_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp_enum.h", "char__samp__enum_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp_set.cpp", "char__samp__set_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_samp_set.h", "char__samp__set_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_set.cpp", "char__set_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/char_set.h", "char__set_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/classifier_base.h", "classifier__base_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/classifier_factory.cpp", "classifier__factory_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/classifier_factory.h", "classifier__factory_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/con_comp.cpp", "con__comp_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/con_comp.h", "con__comp_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/conv_net_classifier.cpp", "conv__net__classifier_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/conv_net_classifier.h", "conv__net__classifier_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_const.h", "cube__const_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_line_object.cpp", "cube__line__object_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_line_object.h", "cube__line__object_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_line_segmenter.cpp", "cube__line__segmenter_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_line_segmenter.h", "cube__line__segmenter_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_object.cpp", "cube__object_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_object.h", "cube__object_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_search_object.cpp", "cube__search__object_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_search_object.h", "cube__search__object_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_tuning_params.cpp", "cube__tuning__params_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_tuning_params.h", "cube__tuning__params_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_utils.cpp", "cube__utils_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/cube_utils.h", "cube__utils_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_base.h", "feature__base_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_bmp.cpp", "feature__bmp_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_bmp.h", "feature__bmp_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_chebyshev.cpp", "feature__chebyshev_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_chebyshev.h", "feature__chebyshev_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_hybrid.cpp", "feature__hybrid_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/feature_hybrid.h", "feature__hybrid_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/hybrid_neural_net_classifier.cpp", "hybrid__neural__net__classifier_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/hybrid_neural_net_classifier.h", "hybrid__neural__net__classifier_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/lang_mod_edge.h", "lang__mod__edge_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/lang_model.h", "lang__model_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/search_column.cpp", "search__column_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/search_column.h", "search__column_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/search_node.cpp", "search__node_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/search_node.h", "search__node_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/search_object.h", "search__object_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/string_32.h", "string__32_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/tess_lang_mod_edge.cpp", "tess__lang__mod__edge_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/tess_lang_mod_edge.h", "tess__lang__mod__edge_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/tess_lang_model.cpp", "tess__lang__model_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/tess_lang_model.h", "tess__lang__model_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/tuning_params.h", "tuning__params_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_altlist.cpp", "word__altlist_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_altlist.h", "word__altlist_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_list_lang_model.cpp", "word__list__lang__model_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_list_lang_model.h", "word__list__lang__model_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_size_model.cpp", "word__size__model_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_size_model.h", "word__size__model_8h.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_unigrams.cpp", "word__unigrams_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cube/word_unigrams.h", "word__unigrams_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/bitvec.cpp", "bitvec_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/bitvec.h", "bitvec_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/callcpp.cpp", "callcpp_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/callcpp.h", "callcpp_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/const.h", "const_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/cutil.cpp", "cutil_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/cutil.h", "cutil_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/cutil_class.cpp", "cutil__class_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/cutil_class.h", "cutil__class_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/danerror.cpp", "danerror_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/danerror.h", "danerror_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/efio.cpp", "efio_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/efio.h", "efio_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/emalloc.cpp", "emalloc_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/emalloc.h", "emalloc_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/freelist.cpp", "freelist_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/freelist.h", "freelist_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/globals.h", "globals_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/listio.cpp", "listio_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/listio.h", "listio_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/oldheap.cpp", "oldheap_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/oldheap.h", "oldheap_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/oldlist.cpp", "oldlist_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/oldlist.h", "oldlist_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/structures.cpp", "structures_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/structures.h", "structures_8h.html", null ],
      [ "/data/source/tesseract-ocr/cutil/tessarray.cpp", "tessarray_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/cutil/tessarray.h", "tessarray_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/context.cpp", "context_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/dawg.cpp", "dawg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/dawg.h", "dawg_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/dict.cpp", "dict_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/dict.h", "dict_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/hyphen.cpp", "hyphen_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/matchdefs.h", "matchdefs_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/permdawg.cpp", "permdawg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/permute.cpp", "permute_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/permute.h", "permute_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/states.cpp", "states_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/states.h", "states_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/stopper.cpp", "stopper_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/stopper.h", "stopper_8h.html", null ],
      [ "/data/source/tesseract-ocr/dict/trie.cpp", "trie_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/dict/trie.h", "trie_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/image.cpp", "image_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/image/image.h", "image_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/img.h", "img_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/imgerrs.h", "imgerrs_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/imgs.cpp", "imgs_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/image/imgs.h", "imgs_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/imgtiff.cpp", "imgtiff_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/image/imgtiff.h", "imgtiff_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/imgunpk.h", "imgunpk_8h.html", null ],
      [ "/data/source/tesseract-ocr/image/svshowim.cpp", "svshowim_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/image/svshowim.h", "svshowim_8h.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ScrollView.java", "_scroll_view_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/events/SVEvent.java", "_s_v_event_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/events/SVEventHandler.java", "_s_v_event_handler_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/events/SVEventType.java", "_s_v_event_type_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVAbstractMenuItem.java", "_s_v_abstract_menu_item_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVCheckboxMenuItem.java", "_s_v_checkbox_menu_item_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVEmptyMenuItem.java", "_s_v_empty_menu_item_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVImageHandler.java", "_s_v_image_handler_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVMenuBar.java", "_s_v_menu_bar_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVMenuItem.java", "_s_v_menu_item_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVPopupMenu.java", "_s_v_popup_menu_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVSubMenuItem.java", "_s_v_sub_menu_item_8java.html", null ],
      [ "/data/source/tesseract-ocr/java/com/google/scrollview/ui/SVWindow.java", "_s_v_window_8java.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/input_file_buffer.cpp", "input__file__buffer_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/input_file_buffer.h", "input__file__buffer_8h.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/neural_net.cpp", "neural__net_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/neural_net.h", "neural__net_8h.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/neuron.cpp", "neuron_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/neuron.h", "neuron_8h.html", null ],
      [ "/data/source/tesseract-ocr/neural_networks/runtime/sigmoid_table.cpp", "sigmoid__table_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/alignedblob.cpp", "alignedblob_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/alignedblob.h", "alignedblob_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/bbgrid.cpp", "bbgrid_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/bbgrid.h", "bbgrid_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/blkocc.cpp", "blkocc_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/blkocc.h", "blkocc_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/colfind.cpp", "colfind_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/colfind.h", "colfind_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartition.cpp", "colpartition_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartition.h", "colpartition_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartitiongrid.cpp", "colpartitiongrid_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartitiongrid.h", "colpartitiongrid_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartitionset.cpp", "colpartitionset_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/colpartitionset.h", "colpartitionset_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/devanagari_processing.cpp", "devanagari__processing_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/devanagari_processing.h", "devanagari__processing_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/drawedg.cpp", "drawedg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/drawedg.h", "drawedg_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/drawtord.cpp", "drawtord_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/drawtord.h", "drawtord_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/edgblob.cpp", "edgblob_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/edgblob.h", "edgblob_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/edgloop.cpp", "edgloop_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/edgloop.h", "edgloop_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/fpchop.cpp", "fpchop_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/fpchop.h", "fpchop_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/gap_map.cpp", "gap__map_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/gap_map.h", "gap__map_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/imagefind.cpp", "imagefind_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/imagefind.h", "imagefind_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/linefind.cpp", "linefind_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/linefind.h", "linefind_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/makerow.cpp", "makerow_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/makerow.h", "makerow_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/oldbasel.cpp", "oldbasel_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/oldbasel.h", "oldbasel_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/pithsync.cpp", "pithsync_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/pithsync.h", "pithsync_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/pitsync1.cpp", "pitsync1_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/pitsync1.h", "pitsync1_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/scanedg.cpp", "scanedg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/scanedg.h", "scanedg_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/sortflts.cpp", "sortflts_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/sortflts.h", "sortflts_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/strokewidth.cpp", "strokewidth_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/strokewidth.h", "strokewidth_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tabfind.cpp", "tabfind_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tabfind.h", "tabfind_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tablefind.cpp", "tablefind_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tablefind.h", "tablefind_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tablerecog.cpp", "tablerecog_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tablerecog.h", "tablerecog_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tabvector.cpp", "tabvector_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tabvector.h", "tabvector_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/textord.cpp", "textord_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/textord.h", "textord_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/topitch.cpp", "topitch_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/topitch.h", "topitch_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tordmain.cpp", "tordmain_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tordmain.h", "tordmain_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/tospace.cpp", "tospace_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tovars.cpp", "tovars_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/tovars.h", "tovars_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/underlin.cpp", "underlin_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/underlin.h", "underlin_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/wordseg.cpp", "wordseg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/wordseg.h", "wordseg_8h.html", null ],
      [ "/data/source/tesseract-ocr/textord/workingpartset.cpp", "workingpartset_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/textord/workingpartset.h", "workingpartset_8h.html", null ],
      [ "/data/source/tesseract-ocr/training/cntraining.cpp", "cntraining_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/combine_tessdata.cpp", "combine__tessdata_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/commontraining.cpp", "commontraining_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/commontraining.h", "commontraining_8h.html", null ],
      [ "/data/source/tesseract-ocr/training/mergenf.cpp", "mergenf_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/mergenf.h", "mergenf_8h.html", null ],
      [ "/data/source/tesseract-ocr/training/mftraining.cpp", "mftraining_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/tessopt.cpp", "tessopt_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/tessopt.h", "tessopt_8h.html", null ],
      [ "/data/source/tesseract-ocr/training/unicharset_extractor.cpp", "unicharset__extractor_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/training/wordlist2dawg.cpp", "wordlist2dawg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/viewer/scrollview.cpp", "scrollview_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/viewer/scrollview.h", "scrollview_8h.html", null ],
      [ "/data/source/tesseract-ocr/viewer/svmnode.cpp", "svmnode_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/viewer/svmnode.h", "svmnode_8h.html", null ],
      [ "/data/source/tesseract-ocr/viewer/svpaint.cpp", "svpaint_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/viewer/svutil.cpp", "svutil_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/viewer/svutil.h", "svutil_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/associate.cpp", "associate_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/associate.h", "associate_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/bestfirst.cpp", "bestfirst_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/bestfirst.h", "bestfirst_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/chop.cpp", "chop_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/chop.h", "chop_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/chopper.cpp", "chopper_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/chopper.h", "chopper_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/closed.cpp", "closed_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/closed.h", "closed_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/drawfx.cpp", "drawfx_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/drawfx.h", "drawfx_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/findseam.cpp", "findseam_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/findseam.h", "findseam_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/gradechop.cpp", "gradechop_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/gradechop.h", "gradechop_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/heuristic.cpp", "heuristic_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/language_model.cpp", "language__model_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/language_model.h", "language__model_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/makechop.cpp", "makechop_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/makechop.h", "makechop_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/matchtab.cpp", "matchtab_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/matchtab.h", "matchtab_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/measure.h", "measure_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/olutil.cpp", "olutil_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/olutil.h", "olutil_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/outlines.cpp", "outlines_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/outlines.h", "outlines_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/pieces.cpp", "pieces_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/pieces.h", "pieces_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/plotedges.cpp", "plotedges_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/plotedges.h", "plotedges_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/plotseg.cpp", "plotseg_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/plotseg.h", "plotseg_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/render.cpp", "render_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/render.h", "render_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/segsearch.cpp", "segsearch_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/tally.cpp", "tally_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/tally.h", "tally_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/tface.cpp", "tface_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/wordclass.cpp", "wordclass_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/wordclass.h", "wordclass_8h.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/wordrec.cpp", "wordrec_8cpp.html", null ],
      [ "/data/source/tesseract-ocr/wordrec/wordrec.h", "wordrec_8h.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

